#pragma once
#include"bool.h"
