#pragma once
void changes_were_made(char*,verado*,int);
void catchSignal(int);
int main(int argc, char* argv[]);